<div class="news--block">
    <div class="simple-marquee-container">
        <div class="marquee">
            <ul class="marquee-content-items">
                <?php foreach ($newsall as $news) : ?>
                    <li class="news--item">
                        <span><?= Yii::$app->formatter->asDate($news->date_news) ?></span>
                        <a href="<?= $news->link_news ?>"><?= $news->text_news ?></a>
                    </li>
                <?php endforeach; ?>
                <?php $date_status = 'высокобюджетный сервер';?>
                <?php foreach ($newsserver as $new) : ?>
                    <?php if ($new->status == 'phavorit_server') : ?>
                        <li class="news--item">
                            <span><?= Yii::$app->formatter->asDate($new->date) ?></span>
                            <span><?= $date_status ?></span>
                            <a href="<?= $new->url ?>"><?= $new->name ?></a>
                            <span>x<?= $new->rate ?></span>
                            <span><?= $new->chronicle ?></span>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>