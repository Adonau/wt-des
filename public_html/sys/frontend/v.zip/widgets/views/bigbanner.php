<?php foreach ($images as $url) : ?>
	<div class="flex-row wrapper--image">
		<a href="<?php
		        if ($url->date_end > date('Y-m-d')) {
					echo $url->link;
				} else {
					echo Yii::$app->urlManager->createUrl(['/']);
				}     					
				?>" target="_blank" style="background-image: url(/image/bg_banner/<?php
																				$main_bg = 'bg-war.jpg';
																				if ($url->date_end > date('Y-m-d')) {
																					echo $url->url;
																				} else {
																					echo $main_bg;
																				}
																				?> )" class="flex-row">
			<span class="flex-column image--text">
				<span class="image--head-txt"><?= $url->text_head ?></span>
				<span class="image--text-cont"><?= $url->text_content ?></span>
			</span>
		</a>
	</div>
<?php endforeach; ?>