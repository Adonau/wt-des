<div class="flex-column statistic--block gray--border">
	<div class="flex-column statistic--list-wrap darck--border">
		<div class="headline statistic--headline">Навигация по популярным разделам</div>
		<div class="flex-row statistic--list-inner">
			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item statistic--day">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/today']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Сегодня</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->date == date('Y-m-d')) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--day">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/tomorrow']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Завтра</div>
						<div class="flex-row statistic--num">
							<?php
							$time = strtotime("+1 day");
							$fecha = date("Y-m-d", $time);
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->date == $fecha) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--day">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/yesterday']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Вчера</div>
						<div class="flex-row statistic--num">
							<?php
							$time = strtotime("-1 day");
							$fecha = date("Y-m-d", $time);
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->date == $fecha) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>

			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item statistic--week">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/nextweek']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Ближайшая неделя</div>
						<div class="flex-row statistic--num">
							<?php
							$time = strtotime("+7 day");
							$fecha = date("Y-m-d", $time);
							$sum = 0;
							foreach ($static as $stat) {
								if (($stat->date > date("Y-m-d")) && ($stat->date <= $fecha)) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--week">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/lastweek']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">На прошлой неделе</div>
						<div class="flex-row statistic--num">
							<?php
							$time = strtotime("-7 day");
							$fecha = date("Y-m-d", $time);
							$sum = 0;
							foreach ($static as $stat) {
								if (($stat->date >= $fecha) && ($stat->date < date("Y-m-d"))) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>

			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/interlude']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Interlude</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'Interlude') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/highfive']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">High Five</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'High Five') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/graciafinal']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Gracia Final</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'Gracia Final') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>

			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/epilogue']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Epilogue</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'Epilogue') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/c4']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">C4</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'C4') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/classic']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Classic</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->chronicle == 'Classic') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>

			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/rvr']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">RvR</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->icon_dp == '<i class="dp--icon">RvR</i>') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/gve']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">GvE</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->icon_dp == '<i class="dp--icon">GvE</i>') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--chronicle">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['chronicle/multiprof']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Мультипрофа</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->icon_dp == '<i class="dp--icon">MuL</i>') {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>

			<ul class="flex-column statistic--list">
				<li class="flex-row statistic--item item--color-gold statistic--bonus">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/budget']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">С высоким бюджетом</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if (($stat->status == 'phavorit_server') + ($stat->status == 'top_server')) {
									if ($stat->getStatus($stat->date_end) != 'simple__server') {
										$stat = 1;
										$sum +=  $stat;
									}
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--bonus">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/obt']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Открытый Бета Тест</div>
						<div class="flex-row statistic--num">
							<?php
							$sum = 0;
							foreach ($static as $stat) {
								if ($stat->getObtHelp($stat->icon_obt) !=  NULL) {
									$stat = 1;
									$sum +=  $stat;
								}
							}
							echo $sum . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
				<li class="flex-row statistic--item statistic--bonus">
					<a class="flex-row statistic--link" href="<?= Yii::$app->urlManager->createUrl(['statistic/bonuses']) ?>">
						<span class="flex-row statistic--round"></span>
						<div class="flex-row statistic--word">Акции и бонусы</div>
						<div class="flex-row statistic--num">
							<?php
							$sumt = 0;
							foreach ($static as $stat) {
								if ($stat->icon_bonus !=  NULL) {
									$stat = 1;
									$sumt +=  $stat;
								}
							}
							echo $sumt . "\n" . 'серв.';
							?>
						</div>
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>