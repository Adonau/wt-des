<footer class="flex-row footer">

    <div class="flex-row footer--contact-wrap">

        <?php foreach ($contact as $cont) : ?>

            <span class="copy--mail"><?= $cont->mail ?></span>
            <span class="copy--icq"><?= $cont->icq ?></span>

            <a href="<?= Yii::$app->urlManager->createUrl(['site/advertising']) ?>" class="copy--link">Реклама на сайте</a>

        <?php endforeach; ?>

    </div>

    <p class="copy--text">Lineage II is a trademarkspan of NCsoft Corporation. Copyright © <a href="https://us.ncsoft.com/" target="_blank" rel="nofollow" class="copy--link-ncsoft">NCsoft</a> Corporation 2005-<?= date('Y') ?>. All rights reserved.</p>

</footer>