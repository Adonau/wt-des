<?php

use yii\helpers\Html;

?>
<header class="flex-row header">
    <div class="flex-column header--title">
        <a href="<?= Yii::$app->urlManager->createUrl(['/']) ?>" class="logo--link">L2wt.ru</a>
        <div class="flex-row header--heading-wrap">
            <h1 class="logo--title"><?= Yii::$app->view->params['title'] ?? ''; ?></h1>
            <span class="logo--line">&nbsp;|&nbsp;</span>
            <span class="logo--undertitle"><?= Yii::$app->view->params['undertitle'] ?? ''; ?></span>
        </div>
    </div>
    <nav class="flex-row header--nav">
    <span class="flex-column gamb--btn-wrap">
            <span class="gamb--btn-item"></span>
        </span>
        <ul class="flex-row header--menu">
            <li class="menu--item">
                <a href="<?= Yii::$app->urlManager->createUrl(['/']) ?>" class="menu--link menu--link--hover">Главная</a>
            </li>
            <li class="menu--item">
                <a href="<?= Yii::$app->urlManager->createUrl(['site/blog']) ?>" class="menu--link menu--link--hover">Наш блог</a>
            </li>
            <li class="menu--item">
                <a href="<?= Yii::$app->urlManager->createUrl(['site/contacts']) ?>" class="menu--link menu--link--hover">Контакты</a>
            </li>
            <li class="menu--item">
                <a href="<?= Yii::$app->urlManager->createUrl(['site/advertising']) ?>" class="menu--link menu--link--hover">Реклама</a>
            </li>
            <li class="add--item menu--item">
                <a href="<?= Yii::$app->urlManager->createUrl(['site/add']) ?>" class="add--link add--link--hover menu--link">Добавить проект</a>
            </li>
        </ul>
    </nav>
</header>