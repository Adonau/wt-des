<?php

use frontend\widgets\NewsWidget;
?>
<aside class="flex-row aside darck--border">
    <div class="flex-column aside--nav">
        <?php echo NewsWidget::widget() ?>
        <div class="flex-column aside--wrap-cnt">

            <div class="flex-row headline aside--headline">Хроники</div>

            <div class="flex-column aside--wrap--menu">
                <div class="flex-row aside--menu-inner">
                    <ul class="flex-column aside--list list--chronicle">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/interlude']) ?>">Interlude</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/epilogue']) ?>">Epilogue</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/c4']) ?>">C4</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/highfive']) ?>">High Five</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/god']) ?>">GoD</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/lindvior']) ?>">Lindvior</a></li>
                    </ul>
                    <ul class="flex-column aside--list list--chronicle">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/graciafinal']) ?>">Gracia Final</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/freya']) ?>">Freya</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/helios']) ?>">Helios</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/classic']) ?>">Classic</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/ertheia']) ?>">Ertheia</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/grcrusade']) ?>">Gr.Crusade</a></li>
                    </ul>
                </div>
                <div class="btn--site aside--item--out">
                    <a href="<?= Yii::$app->urlManager->createUrl(['/']) ?>">Все хроники</a>
                </div>
            </div>
            <span class="flex-row headline aside--headline tipe--server">Тип сервера</span>
            <div class="flex-column aside--wrap--menu">
                <div class="flex-row aside--menu-inner">
                    <ul class="flex-column aside--list list--chronicle">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/rvr']) ?>">RvR</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/multiprof']) ?>">MultiProf</a></li>
                    </ul>
                    <ul class="flex-column aside--list list--chronicle">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['chronicle/gve']) ?>">GvE</a></li>
                    </ul>
                </div>
                <div class="btn--site aside--item--out">
                    <a href="<?= Yii::$app->urlManager->createUrl(['/']) ?>">Все типы</a>
                </div>
            </div>
        </div>
        <?php foreach ($aside as $as) : ?>
            <div class="aside--banner">
                <a href="<?php
                            if ($as->date_end > date('Y-m-d')) {
                                echo $as->bannerLink;
                            } else {
                                echo Yii::$app->urlManager->createUrl(['/']);
                            }
                            ?>" target="_blank" style="background-image: url(/image/gif_aside/<?php
                                                                                                    $main_as = 'gif-main.jpg';
                                                                                                    if ($as->date_end > date('Y-m-d')) {
                                                                                                        echo $as->bannerUrl;
                                                                                                    } else {
                                                                                                        echo $main_as;
                                                                                                    }
                                                                                                    ?>);"></a>
            </div>
        <?php endforeach; ?>
        <div class="flex-column aside--wrap-cnt">

            <div class="flex-row headline aside--headline">Рейты</div>

            <div class="flex-column aside--wrap--menu">
                <div class="flex-row aside--menu-inner">
                    <ul class="flex-column aside--list list--rate">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x1_x10']) ?>">x1-x10</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x10_x50']) ?>">x10-x50</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x50_x100']) ?>">x50-x100</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x100_x500']) ?>">x100-x500</a></li>
                    </ul>
                    <ul class="flex-column aside--list list--rate">
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x500_x1000']) ?>">x500-x1000</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x1000_x5000']) ?>">x1000-x5000</a></li>
                        <li class="btn--site aside--btn"><a href="<?= Yii::$app->urlManager->createUrl(['rate/x5000']) ?>">x5000 +</a></li>
                    </ul>
                </div>
                <div class="btn--site aside--item--out">
                    <a href="<?= Yii::$app->urlManager->createUrl(['/']) ?>">Все рейты</a>
                </div>
            </div>

        </div>
    </div>
</aside>