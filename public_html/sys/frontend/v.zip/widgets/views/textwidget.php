<div class="flex-column text--la-inner darck--border">
    <div class="flex-column text--la-cnt">
        <?= Yii::$app->view->params['title-prefotter'] ?? ''; ?>
        <?= Yii::$app->view->params['text-prefotter'] ?? ''; ?>
        <?= Yii::$app->view->params['title-main'] ?? ''; ?>
        <?= Yii::$app->view->params['text-main'] ?? ''; ?>
    </div>
</div>