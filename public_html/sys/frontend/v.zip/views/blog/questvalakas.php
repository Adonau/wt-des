<?php

/* @var $this yii\web\View */

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/blog/questvalakas';
$this->title = 'Квест на проход к Валакаса в картинках';
$this->registerMetaTag(['name' => 'description', 'content' => 'Квеста на Валакасу в картинках и с полным описанием.']);
$this->registerMetaTag(['name' => 'keywords', 'content' => 'Квест на Валакасу, квест на проход к Валакасу']);
Yii::$app->view->params['title'] = 'Квест на Валакаса в картинках';
Yii::$app->view->params['undertitle'] = 'полное описание квеста на проход к Валакасу';
?>

<div class="flex-column page page--blog darck--border">
    <div class="headline blog--headline">Квест на Валакаса</div>
    <div class="flex-column wrap--section-blog">
        <p><b>Валакас (Valakas)</b> – Это один из шести драконов сын Шилен и Гран Кайна, эпический рейд босс. Имеет заветный дроп в виде кулона Валакаса и различного обмундирования, объект многих бессонных ночей и жарких битв. Довольно неприятный для убийства благодаря скилам массового фира, урон по площади огнём, постоянно появляются мобы в виде мелких голов дракона.</p>
    </div>
    <div class="flex-column wrap--section-blog">
        <div class="flex-row inner--section-blog klein--section">
            <img src="/image/quest_img/quest_valacas/klein.jpg" alt="klein image, lineage2">
            <p>1) Квест берётся у npc <b>Klein</b> находится в локации города <b>Goddard - Forge of Gods (Кузница Богов)</b>. Название квеста <b>Into the Flames (Прямиком в пламя)</b>. <b>Доступен с 60го уровня</b>. <br><br><b>В хрониках High Five и выше квест итем остаётся у игрока.</b></p>
        </div>
    </div>
    <div class="flex-column wrap--section-blog">
        <div class="flex-row inner--section-blog map-section">
            <p>2) Волею судеб оказываемся около входа в пещеру <b>Forge of Gods (Кузница Богов)</b>. Прыгаем вниз или спускаемся по витому спуску, бежим прямо, пробегаем мост, в первой и других комнатах нас ждут агрессивные социальные мобы. <br><br> Используем на себя любой скилл(свитки, что угодно) полностью убирающий агрессию мобов, пробегаем комнату, поворачиваем налево бежим, потом всё время на право как указанно на карте. <br><br>Добежав до круга поворачиваем направо пробегаем 1/4 и видим npc <b>Klein</b> по левую руку от нас.</p>
            <img src="/image/quest_img/quest_valacas/intomap.jpg" alt="map fog, lineage2">
        </div>
    </div>
    <div class="flex-column wrap--section-blog">
        <div class="flex-row inner--section-blog hilda--section">
            <img src="/image/quest_img/quest_valacas/Hilda.jpg" alt="hilda image, goddard lineage2">
            <p>3) После того как взяли квест у <b>Klein'на</b> делаем сое, оказываемся в <b>Goddard</b>, бежим в кузницу (blacksmith) отыскиваем там кузнеца <b>Hilda</b> говорим с ней, она просит нас принести 50шт <b>Vacualite ore (Руда Вакуалита)</b>.</p>
        </div>
        <div class="flex-column inner--section-blog ">
            <p><b>Vacualite ore (Руда Вакуалита)</b> выбивается с мобов: <b>Kookaburra (Кукабарра)</b>, <b>Bandersnatch (Драколов)</b>, <b>Grendel (Грендель)</b>.</p>
            <div class="flex-row blog--img-wrap img--valakas--mbs">
                <div class="flex-row img--wrap">
                    <img src="/image/quest_img/quest_valacas/kookaburra.jpg" alt="Kookaburra image, lineage2">
                </div>
                <div class="flex-row img--wrap">
                    <img src="/image/quest_img/quest_valacas/Bandersnatch.jpg" alt="Bandersnatch image, lineage2">
                </div>
                <div class="flex-row img--wrap">
                    <img src="/image/quest_img/quest_valacas/Grendel2.jpg" alt="Grendel image, lineage2">
                </div>
            </div>
        </div>
    </div>
    <div class="flex-column wrap--section-blog">
        <div class="flex-row inner--section-blog">
            <p>5) По завершению сбора квест итемов, возвращаемся обратно к <b>Hilda</b> она нам выдаст <b>Vacualite(Вакуалит)</b>, летим в <b>Forge of Gods(Кузница Богов)</b> отдаём <b>Vacualite(Вакуалит) Klein'ну</b> он обменяет его на <b>Vacualite Floating Stone(Парящий Камень Вакуалита)</b>.<br><br><b>Вот и весь квест, по сравнению с тарасом быстрый и лёгкий</b><br><br>Не будем расписывать как действовать дальше, всегда найдутся люди которые будут командовать вашим цц. Лимит на проход к Валакасу зависит от настройки сервера, советуем предварительно получить информацию, сколько требуется человек для прохода, каковы настройки рейд босса. В общем чекайте форум вашего сервера на предмет респауна, лимитов и т.п.</p>
        </div>
    </div>

    <div class="btn--site btn--quest">
        <a href="<?= Yii::$app->urlManager->createUrl(['/blog']) ?>">Общий раздел</a>
    </div>
</div>