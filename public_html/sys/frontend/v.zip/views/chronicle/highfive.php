<?php

/* @var $this yii\web\View */

$this->title = 'Сервера Lineage 2  High Five (Хай Файв)';
use yii\i18n\Formatter;
use yii\helpers\ArrayHelper;

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/highfive';
$this->registerMetaTag(['name' => 'description', 'content' => '"L2wt.ru" Анонсы бесплатных, новых и уже открывшихся, pvp и low рейт серверов lineage 2 High Five (Хай Файв). ']);
Yii::$app->view->params['title'] = 'Новые сервера Lineage 2  High Five';
Yii::$app->view->params['undertitle'] = 'пвп и лоу рейт сервера / <b>Хай Файв</b>';
?>
<div class="flex-row page page--server">
	<div class="flex-column page--server-content server--content-left">
		<div class="headline server--headline">Сервера ожидающие открытия</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php $showed = false; ?>
				<?php foreach ($list_earlier_vip as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date >= date('Y-m-d')) : ?>
						<?php if ($list->getStatus($list->date_end) != 'simple__server') : ?>
							<?php if ($list->status <= 'top_server') : ?>
								<?php
								if (!$showed) {
									echo '
									<div class="flex-row server--container-headline headline--hight">
									    <i class="fa fa-btc" aria-hidden="true"></i>&nbsp;- высокобюджетные сервера		
								    </div>';
									$showed = true;
								}
								?>
								<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
									<?= $list->getStar($list->icon_star) ?>
									<div class="basis--link-item server--item-name">
										<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
											<?= $list->name ?></a>
										<div class="flex-row icon--wrap">
											<div class="basis--link-item server--item-obt">
												<?= $list->icon_obt ?>
												<?= $list->getObtText($list->text_obt) ?>
											</div>
											<div class="basis--link-item server--item-start">
												<?= $list->icon_bonus ?>
												<?= $list->getBonusText($list->text_bonus) ?>
											</div>
										</div>
									</div>
									<?= $list->getMoneyHelp($list->icon_money) ?>
									<?= $list->getRate($list->rate) ?>
									<div class="basis--link-item server--item-chronicle">
										<?= $list->chronicle ?>
										<div class="basis--link-item server--item-dp">
											<?= $list->icon_dp ?>
											<?= $list->text_dop ?>
										</div>
									</div>
									<div class="basis--link-item server--item-date">
										<?= Yii::$app->formatter->asDate($list->date) ?>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$showed = false;
				$today = 'Сегодня';
				?>
				<?php foreach ($list_earlier as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date == date('Y-m-d')) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Сегодня : ' . Yii::$app->formatter->asDate('now', 'full') . '</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$tomorrow = 'Завтра';
				$time = strtotime("+1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if ($list->date == $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Завтра</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time2 = strtotime("+7 day");
				$fecha2 = date("Y-m-d", $time2);
				$time = strtotime("+1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if (($list->date > $fecha) && ($list->date <= $fecha2)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Ближайщую неделю</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container box__all">
				<?php
				$time = strtotime("+7 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if ($list->date > $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Через неделю и более</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="flex-column page--server-content server--content-right">
		<div class="headline server--headline">Сервера которые открылись</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php $showed = false; ?>
				<?php foreach ($list_already_vip as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date < date('Y-m-d')) : ?>
						<?php if ($list->getStatus($list->date_end) != 'simple__server') : ?>
							<?php if ($list->status <= 'top_server') : ?>
								<?php if (!$showed) {
									echo '
										<div class="flex-row server--container-headline headline--hight">
										    <i class="fa fa-btc" aria-hidden="true"></i>&nbsp;- высокобюджетные сервера		
										</div>';
									$showed = true;
								} ?>
								<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
									<?= $list->getStar($list->icon_star) ?>
									<div class="basis--link-item server--item-name">
										<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
											<?= $list->name ?></a>
										<div class="flex-row icon--wrap">
											<div class="basis--link-item server--item-obt">
												<?= $list->icon_obt ?>
												<?= $list->getObtText($list->text_obt) ?>
											</div>
											<div class="basis--link-item server--item-start">
												<?= $list->icon_bonus ?>
												<?= $list->getBonusText($list->text_bonus) ?>
											</div>
										</div>
									</div>
									<?= $list->getMoneyHelp($list->icon_money) ?>
									<?= $list->getRate($list->rate) ?>
									<div class="basis--link-item server--item-chronicle">
										<?= $list->chronicle ?>
										<div class="basis--link-item server--item-dp">
											<?= $list->icon_dp ?>
											<?= $list->text_dop ?>
										</div>
									</div>
									<div class="basis--link-item server--item-date">
										<?= Yii::$app->formatter->asDate($list->date) ?>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$yesterday = 'Вчера';
				$time = strtotime("-1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date == $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Вчера</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-1 day");
				$fecha = date("Y-m-d", $time);
				$time2 = strtotime("-7 day");
				$fecha2 = date("Y-m-d", $time2);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>
					<?php if (($list->date >= $fecha2) && ($list->date < $fecha)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">На прошлой неделе</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-7 day");
				$fecha = date("Y-m-d", $time);
				$time2 = strtotime("-30 day");
				$fecha2 = date("Y-m-d", $time2);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>				
					<?php if (($list->date >= $fecha2) && ($list->date < $fecha)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Более недели назад</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-30 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>				
					<?php if ($list->date < $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Более месяца назад</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>