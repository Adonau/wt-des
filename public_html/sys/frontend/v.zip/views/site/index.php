<?php

/* @var $this yii\web\View */
use yii\i18n\Formatter;
use yii\helpers\ArrayHelper;

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/';	
$this->title = 'Анонсы серверов Lineage 2 | Новые сервера л2 | L2wt.ru';
$this->registerMetaTag(['name' => 'description', 'content' => 'Анонсы серверов Lineage 2 всех рейтов и хроник. У нас вы найдете только новые сервера л2 которые прошли модерацию и ожидают своих игроков.']);
$this->registerMetaTag(['name' => 'keywords', 'content' => 'Анонсы серверов л2, новые сервера л2, сервера л2']);
Yii::$app->view->params['title'] = 'Анонсы серверов Lineage 2';
Yii::$app->view->params['undertitle'] = 'новые сервера Lineage 2';
?>
<div class="flex-row page page--server">
	<div class="flex-column page--server-content server--content-left">
		<div class="headline server--headline">Сервера ожидающие открытия</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php $showed = false; ?>
				<?php foreach ($list_earlier_vip as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date >= date('Y-m-d')) : ?>
						<?php if ($list->getStatus($list->date_end) != 'simple__server') : ?>
							<?php if ($list->status <= 'top_server') : ?>
								<?php
								if (!$showed) {
									echo '
									<div class="flex-row server--container-headline headline--hight">
									    <i class="fa fa-btc" aria-hidden="true"></i>&nbsp;- высокобюджетные сервера		
								    </div>';
									$showed = true;
								}
								?>
								<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
									<?= $list->getStar($list->icon_star) ?>
									<div class="basis--link-item server--item-name">
										<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
											<?= $list->name ?></a>
										<div class="flex-row icon--wrap">
											<div class="basis--link-item server--item-obt">
												<?= $list->icon_obt ?>
												<?= $list->getObtText($list->text_obt) ?>
											</div>
											<div class="basis--link-item server--item-start">
												<?= $list->icon_bonus ?>
												<?= $list->getBonusText($list->text_bonus) ?>
											</div>
										</div>
									</div>
									<?= $list->getMoneyHelp($list->icon_money) ?>
									<?= $list->getRate($list->rate) ?>
									<div class="basis--link-item server--item-chronicle">
										<?= $list->chronicle ?>
										<div class="basis--link-item server--item-dp">
											<?= $list->icon_dp ?>
											<?= $list->text_dop ?>
										</div>
									</div>
									<div class="basis--link-item server--item-date">
										<?= Yii::$app->formatter->asDate($list->date) ?>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$showed = false;
				$today = 'Сегодня';
				?>
				<?php foreach ($list_earlier as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date == date('Y-m-d')) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Сегодня : ' . Yii::$app->formatter->asDate('now', 'full') . '</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$tomorrow = 'Завтра';
				$time = strtotime("+1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if ($list->date == $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Завтра</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time2 = strtotime("+7 day");
				$fecha2 = date("Y-m-d", $time2);
				$time = strtotime("+1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if (($list->date > $fecha) && ($list->date <= $fecha2)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Ближайщую неделю</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container box__all">
				<?php
				$time = strtotime("+7 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_earlier as $list) : ?>
					<?php if ($list->date > $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Через неделю и более</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="flex-column page--server-content server--content-right">
		<div class="headline server--headline">Сервера которые открылись</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php $showed = false; ?>
				<?php foreach ($list_already_vip as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date < date('Y-m-d')) : ?>
						<?php if ($list->getStatus($list->date_end) != 'simple__server') : ?>
							<?php if ($list->status <= 'top_server') : ?>
								<?php if (!$showed) {
									echo '
										<div class="flex-row server--container-headline headline--hight">
										    <i class="fa fa-btc" aria-hidden="true"></i>&nbsp;- высокобюджетные сервера		
										</div>';
									$showed = true;
								} ?>
								<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
									<?= $list->getStar($list->icon_star) ?>
									<div class="basis--link-item server--item-name">
										<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
											<?= $list->name ?></a>
										<div class="flex-row icon--wrap">
											<div class="basis--link-item server--item-obt">
												<?= $list->icon_obt ?>
												<?= $list->getObtText($list->text_obt) ?>
											</div>
											<div class="basis--link-item server--item-start">
												<?= $list->icon_bonus ?>
												<?= $list->getBonusText($list->text_bonus) ?>
											</div>
										</div>
									</div>
									<?= $list->getMoneyHelp($list->icon_money) ?>
									<?= $list->getRate($list->rate) ?>
									<div class="basis--link-item server--item-chronicle">
										<?= $list->chronicle ?>
										<div class="basis--link-item server--item-dp">
											<?= $list->icon_dp ?>
											<?= $list->text_dop ?>
										</div>
									</div>
									<div class="basis--link-item server--item-date">
										<?= Yii::$app->formatter->asDate($list->date) ?>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$yesterday = 'Вчера';
				$time = strtotime("-1 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date == $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Вчера</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-1 day");
				$fecha = date("Y-m-d", $time);
				$time2 = strtotime("-7 day");
				$fecha2 = date("Y-m-d", $time2);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>
					<?php if (($list->date >= $fecha2) && ($list->date < $fecha)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">На прошлой неделе</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-7 day");
				$fecha = date("Y-m-d", $time);
				$time2 = strtotime("-30 day");
				$fecha2 = date("Y-m-d", $time2);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>				
					<?php if (($list->date >= $fecha2) && ($list->date < $fecha)) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Более недели назад</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$time = strtotime("-30 day");
				$fecha = date("Y-m-d", $time);
				$showed = false;
				?>
				<?php foreach ($list_already as $list) : ?>				
					<?php if ($list->date < $fecha) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Более месяца назад</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
							<?= $list->getStar($list->icon_star) ?>
							<div class="basis--link-item server--item-name">
								<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
									<?= $list->name ?></a>
								<div class="flex-row icon--wrap">
									<div class="basis--link-item server--item-obt">
										<?= $list->icon_obt ?>
										<?= $list->getObtText($list->text_obt) ?>
									</div>
									<div class="basis--link-item server--item-start">
										<?= $list->icon_bonus ?>
										<?= $list->getBonusText($list->text_bonus) ?>
									</div>
								</div>
							</div>
							<?= $list->getMoneyHelp($list->icon_money) ?>
							<?= $list->getRate($list->rate) ?>
							<div class="basis--link-item server--item-chronicle">
								<?= $list->chronicle ?>
								<div class="basis--link-item server--item-dp">
									<?= $list->icon_dp ?>
									<?= $list->text_dop ?>
								</div>
							</div>
							<div class="basis--link-item server--item-date">
								<?= Yii::$app->formatter->asDate($list->date) ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>
<?php
Yii::$app->view->params['text-prefotter'] = '<p>В задачи платформ анонсирующих приватные сервера Lineage 2 входит отобрать и допустить до конечного пользователя только качественные сервера л2 на базе PTS или Java сборок. Множество игроков предпочитают определенные хроники, особой популярностью пользуются Interlude, Epilogue, High Five именно по этой причине приватные сервера так популярны. Многие платформы, предоставляющие площадку под анонсы серверов л2, ужесточили правила добавления серверов, мы не исключение. Для более  детального понимания ниже мы описали что представляет из себя наша платформа.</p>' .
	'<div class="flex-row text--dot">
	<span></span>
	<span></span>
	<span></span>
</div>' . 
'<h2 class="text--la-headline">Новые сервера л2 всех хроник и рейтов</h2>
<p>Хотя сама игра Lineage 2 в привычном нам виде была анонсирована в Южной Корее 1 октября 2003 года новы сервера открываются каждый день, наша добрая старушка л2 всё еще популярна, а на дворе смеем заметить уже 2019, тысячи игроков ежедневно находятся в поиске новых серверов и задаются вопросом на каких хрониках поиграть и какие рейты опробовать (насчёт тысячей, это не преувеличение). У нас вы может подобрать новые или уже открывшиеся сервера на любой вкус, начиная от мутипрофы заканчивая рвр проектами, а между делом закусить серверами с крыльями бабочек и пуха +100000, огромный выбор уже давно известных проектов, которые заслужили своё место на пьедестале и только начинающими свой путь, а как выбрать сервер правильно мы описали ниже, надеемся вам помогут наши советы в выборе сервера вашей мечты.</p>
<div class="flex-row text--dot">
	<span></span>
	<span></span>
	<span></span>
</div>' .
	'<h2 class="text--la-headline">Советы по выбору нового сервера</h2>
<p>Несмотря на все ужесточения и проверки новых серверов л2, все же прорываются неблагонадёжные, просим обращать более детальное внимание на все новые и незнакомые вам сервера, где вы решили играть, а точнее есть ли крупные накрутки онлайна, есть ли форум и какова активность на нём. Обратите внимание на вёрстку сайта, не плывут ли элементы навигации или основных разделов (мало кто адаптирует сайт под мобильные устройства в сфере л2, так что особо не заморачивайтесь с этим, хотя это тоже можно отнести к знаку качества). Относитесь бдительно к платёжным системам и самой концепции сервера.</p>' .
	'<div class="flex-row text--dot">
	<span></span>
	<span></span>
	<span></span>
</div>';

Yii::$app->view->params['title-main'] = '<h2 class="text--la-headline">Кратко о сайте L2wt.ru</h2>';
Yii::$app->view->params['text-main'] = '
<p>Платформа L2wt.ru (Lineage 2 web tool | веб инструмент) специализируется на анонсах частных проектов Lineage 2 данные проекты созданы исключительно для ознакомления игроками с миром Lineage 2 и со всеми его прелестями. Мы стараемся отобрать только надежные проекты (насколько это возможно). Проекты, зарегистрированные у нас, прошли модерацию и мы ознакомились с их концепцией. В ваших же силах воспользоваться нашим сайтом как инструментом, для выбора наилучшего сервера из ряда представленных. Мы стараемся придерживаться минималистического варианта как в дизайне сайта, так и в информации, которая поступает конечному пользователю, без потери исчерпывающих данных</p>
<div class="flex-row list--dot">
	<span></span>
	<span></span>
	<span></span>
</div>
<h3 class="text--la-headline-h3">Структура нашего сайта</h3>
<ul class="flex-column text--list">
	<li>В верхней части сайта расположена навигация по популярным разделам, хроникам и дням недели.</li>
	<li>Слева навигация по всем остальным разделам.</li>
	<li>В левой колонке перечислены сервера, ожидающие открытия, В правой - открывщиеся.</li>
	<li><i class="fa fa-star" aria-hidden="true"></i> - Проект, обладающий данной иконкой, является фаворитом нашего портала.</li>
	<li><i class="fa fa-star-half-o" aria-hidden="true"></i> - Данный вариант показывает, что проект имеет ТОП статус и распологается в верхних строчках списка серверов.</li>
	<li><i class="fa fa-star-o" aria-hidden="true"></i> - Обладатели данной ВИП иконки хотят выделиться по отношению к бесплатно зарегестрированным серверам.</li>
</ul>
';
?>