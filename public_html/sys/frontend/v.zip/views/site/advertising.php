<?php

/* @var $this yii\web\View */

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/advertising';
$this->title = 'Реклама вашего проекта Lineage 2 на нашей платформе.';
$this->registerMetaTag(['name' => 'description', 'content' => 'На этой странице вы можете ознакомиться с ценами на размещение вашего проекта на нашем сайте.']);
Yii::$app->view->params['title'] = 'Реклама на L2wt.ru';
Yii::$app->view->params['undertitle'] = 'Цены на размещение вашего проекта';
?>
<div class="flex-column page page--advert darck--border">
	<div class="headline advert--heading">Реклама на нашей платформе</div>
	<div class="flex-column advert--section advert--btn-section gray--border">
		<div class="adv-headline darck--border">Правила free или эконом размещения :</div>
		<div class="flex-row textarea--section darck--border">
			<ul class="flex-column textarea--list">
			    <li class="flex-row textarea--item">На данном этапе все сервера размещаются соверщенно бесплатно!</li>
				<li class="flex-row textarea--item">При добавлении сервера на безвозмездной основе, вы должны установить нашу кнопку на ваш сайт.</li>
				<li class="flex-row textarea--item">Позицианирование кнопки может быть изменено (top/bottom/right/left) в случае если она закрывает важные элементы навигации сайта.</li>
			</ul>

			<div class="flex-column textarea--image-text-wrap">

				<div class="flex-row textarea--image-wrap">
					<span class="textarea--text">Образец кнопки :</span>
					<span class="textarea--image"></span>
				</div>

				<textarea id="icon--l2wt" readonly><a href="/go?url=aHR0cDovL2wyd3QucnU%3D" target="_blank" style="position: fixed; right: 25px; top: 25px; z-index: 99999; border: 1px solid #261B13; height: 80px; box-shadow: 0 0 5px 1px #000;" title="Анонсы серверов Lineage 2, новые сервера л2" alt="Анонсы серверов Lineage 2, новые сервера л2"><img src="http://l2wt.ru/image/iconl2wt/l2wt-icon.jpg" alt=""></a></textarea>
			</div>
		</div>
	</div>


	<?php foreach ($adv as $ad) : ?>


		<div class="flex-column advert--section gray--border">

			<div class="adv-headline darck--border">Баннерна реклама :</div>

			<div class="flex-column advert--wrap-list darck--border">
				<ul class="flex-column small--banner-list">
					<li class="adv--item">Размер банера(px) : <span>240х400.</span></li>
					<li class="adv--item">Расширения : <span>gif, png, jpg.</span></li>
					<li class="adv--item">Максимальный вес : <span>200кб.</span></li>
					<li class="adv--item">30 дней &nbsp - &nbsp <span><?= $ad->small_banner ?>.</span></li>
					<li class="margin--item adv--item"><span>Не допустимо</span> : слишком яркие цвета, анимация c частым миганием.</li>
				</ul>
			</div>
		</div>

		<div class="flex-column advert--section gray--border">

			<div class="adv-headline darck--border">Центральный баннер :</div>

			<div class="flex-column advert--wrap-list darck--border">
				<ul class="flex-column big--banner-list">
					<li class="adv--item">Размер банера(px) : <span>минимальный 930х300.</span></li>
					<li class="adv--item">Расширения : <span>jpg, png.</span></li>
					<li class="adv--item">Максимальный вес : <span>500кб.</span></li>
					<li class="adv--item">30 дней &nbsp - &nbsp <span><?= $ad->big_banner ?>.</span></li>
					<li class="margin--item adv--item"><span>Не допустимо</span> : слишком яркие цвета, анимация.</li>
					<li class="adv--item"><span>В плашке баннера может размещаться любой текст.</span></li>
				</ul>
			</div>
		</div>

		<div class="flex-column advert--section gray--border">

			<div class="flex-row adv-headline darck--border">Фаворит статус :
				<div class="basis--link-item server--item-icon">
					<i class="fa fa-star" aria-hidden="true"></i>
				</div>
			</div>

			<div class="flex-column advert--wrap-list darck--border">

				<ul class="phavorit--list">
					<li class="adv--item">Позиция в премиум блоке : <span>возглавляет.</span></li>
					<li class="adv--item">Дублируется :<span> да.</span></li>
					<li class="adv--item">Позиция в остальных блоках : <span>возглавляет все блоки.</span></li>
					<li class="adv--item">Размешение кнопки : <span>не требуется.</span></li>
					<li class="margin--item adv--item">
						<span>Если при переходе из левого в правый блок позиция фаворит будет занята, то сервер переносится в TOP статус, оставшийся срок увеличивается в 2 раза.</span>
					</li>
					<li class="margin--item adv--item">Позиций на сайте : <span>В левом блоке 1 позиция. В павом 1 позиция.</span></li>
					<li class="adv--item">
						В левом занято до &nbsp &nbsp - &nbsp
						<span>
							<?php foreach ($list_earlier as $serv) {

								if ($serv->date > date('Y-m-d')) {

									if ($serv->status == 'phavorit_server') {

										if ($serv->getStatus($serv->date_end) != 'simple__server') {

											echo Yii::$app->formatter->asDate($serv->date_end, 'long');
										}
									}
								}
							} ?>

						</span>
					</li>
					<li class="adv--item">
						В правом занято до &nbsp - &nbsp
						<span>
							<?php foreach ($list_earlier as $serv) {

								if ($serv->date < date('Y-m-d')) {

									if ($serv->status == 'phavorit_server') {

										if ($serv->getStatus($serv->date_end) != 'simple__server') {

											echo Yii::$app->formatter->asDate($serv->date_end, 'long');
										}
									}
								}
							} ?>
						</span>
					</li>
					<li class="margin--item adv--item">30 дней &nbsp - &nbsp <span><?= $ad->price__phavorit ?>.</span></li>
				</ul>

			</div>
		</div>

		<div class="flex-column advert--section gray--border">

			<div class="flex-row adv-headline darck--border">Топ статус :
				<div class="basis--link-item server--item-icon">
					<i class="fa fa-star-half-o" aria-hidden="true"></i>
				</div>
			</div>

			<div class="flex-column advert--wrap-list darck--border">

				<ul class="top--list">

					<li class="adv--item">Позиция в премиум блоке : <span>находится в премиум блоке.</span></li>
					<li class="adv--item">Дублируется : <span>да.</span></li>
					<li class="adv--item">Позиция в остальных блоках : <span>всегда выше ВИП серверов.</span></li>
					<li class="adv--item">Дизайн : <span>более контрастный по сравнению с ВИП и обычными серверами.</span></li>
					<li class="adv--item">Размешение кнопки: <span>не требуется.</span></li>
					<li class="margin--item adv--item">Позиций на сайте : <span>16.</span></li>
					<li class="adv--item">
						Занято позиций :
						<span>
							<?php $sum = 0; ?>

							<?php foreach ($list_earlier as $serv) {

								if ($serv->status == 'top_server') {

									if ($serv->getStatus($serv->date_end) != 'simple__server') {

										$serv = 1;
										$sum += $serv;
									}
								}
							}
							echo $sum; ?>.</span>
					</li>
					<li class="adv--item margin--item">30 дней &nbsp - &nbsp <span><?= $ad->price__top ?>.</span></li>
					<li class="adv--item">15 дней &nbsp - &nbsp <span><?= $ad->price__top_two ?>.</span></li>

					<li class="adv--item margin--item"><span>Эконом размещение (с добавлением кнопки на ваш сайт).</span></li>
					<li class="adv--item margin--item">30 дней &nbsp - &nbsp <span><?= $ad->price_top_econ ?>.</span></li>
					<li class="adv--item">15 дней &nbsp - &nbsp <span><?= $ad->price_top_two_econ ?>.</span></li>

				</ul>

			</div>
		</div>

		<div class="flex-column advert--section gray--border">

			<div class="flex-row adv-headline darck--border">Вип статус :
				<div class="basis--link-item server--item-icon">
					<i class="fa fa-star-o" aria-hidden="true"></i>
				</div>
			</div>

			<div class="advert--wrap-list darck--border">

				<ul class="vip--list">
					<li class="adv--item">Позиция : <span>Находится выше обычных серверов.</span></li>
					<li class="adv--item">Дублируется : <span>нет.</span></li>
					<li class="adv--item">Дизайн : <span>более контрастный по сравнению с обычными серверами.</span></li>
					<li class="adv--item">Размешение кнопки : <span>не требуется.</span></li>
					<li class="margin--item adv--item">Позиций на сайте : <span>неограниченно.</span></li>
					<li class="margin--item adv--item">30 дней &nbsp - &nbsp <span><?= $ad->price__vip ?>.</span></li>
					<li class="adv--item">15 дней &nbsp - &nbsp <span><?= $ad->price__vip_two ?>.</span></li>
					<li class="adv--item">10 дней &nbsp - &nbsp <span><?= $ad->price__vip_three ?>.</span></li>

					<li class="adv--item margin--item"><span>Эконом размещение (с добавлением кнопки на ваш сайт).</span></li>
					<li class="adv--item margin--item">30 дней &nbsp - &nbsp <span><?= $ad->price_vip_econ ?>.</span></li>
					<li class="adv--item">15 дней &nbsp - &nbsp <span><?= $ad->price_vip_two_econ ?>.</span></li>
					<li class="adv--item">10 дней &nbsp - &nbsp <span><?= $ad->price_vip_three_econ ?>.</span></li>
				</ul>

			</div>
		</div>

		<div class="flex-column advert--section gray--border">

			<div class="adv-headline darck--border">Бегущая строка в асайд (левое меню) :</div>

			<div class="advert--wrap-list darck--border">
				<ul>
					<li class="adv--item">Для фаворит статуса : <span>Размещение бесплатное, автоматическое (всё время действия статуса).</span></li>
					<li class="adv--item">Для сервров находящихся в разделе <span>"сегодня"</span> : <span>Размещение бесплатное, автоматическое (в зависисмости от даты).</span></li>
					<li class="adv--item">Для сервров находящихся в разделе <span>"вчера"</span> : <span>Размещение бесплатное, автоматическое (в зависисмости от даты).</span></li>
					<li class="margin--item adv--item">Для остольных серверов : <span>Доступно в зависимости от даты.</span></li>
				</ul>
			</div>
		</div>
	<?php endforeach; ?>
</div>