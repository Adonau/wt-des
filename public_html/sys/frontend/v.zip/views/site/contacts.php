<?php
/* @var $this yii\web\View */

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/contacts';
$this->title = 'Контакты администрации L2wt.ru';
$this->registerMetaTag(['name' => 'description', 'content' => 'Контакты администрации L2wt.ru']);
$this->registerMetaTag(['name' => 'keywords', 'content' => 'Контакты администрации L2wt.ru']);
Yii::$app->view->params['title'] = 'Контакты администрации L2wt.ru';
Yii::$app->view->params['undertitle'] = 'контакты и реквизиты';

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
?>
<div class="flex-column darck--border page page--contacts">
    <?php foreach ($contact as $cont) : ?>
        <div class="headline contacts--headline">Контакты и реквизиты</div>
        <div class="flex-row contacts--section">

            <span class="flex-row contact--item contact--mail">
                <i class="fa fa-envelope-o" aria-hidden="true"></i>
                <span class="mail--address"><?= $cont->mail ?></span>
            </span>
            <span class="flex-row contact--item contact--icq">
                <span class="icq--icon"></span>
                <span class="icq--numeral"><?= $cont->icq ?></span>
            </span>

        </div>
        <div class="flex-row contacts--section">

            <div class="flex-column requisites--item requisites--ru">
                <span class="item--text">WMR (рубль) -</span>
                <span class="item--address">-<?= $cont->other_one ?></span>
            </div>
            <div class="flex-column requisites--item requisites--usd">
                <span class="item--text">WMZ (доллар) -</span>
                <span class="item--address">-<?= $cont->other__two ?></span>
            </div>

        </div>

    <?php endforeach; ?>
    <p>Для связи с администрацией платформы вы можете использовать данные указанные выше или написать нам напрямую, оставив свою почту и указав как к вам обращаться, на которую мы обязательно пришлём вам ответ.</p>
    <div class="flex-row contacts--form-wrap">
        <?php $form = ActiveForm::begin(['id' => 'contacts--form', 'options' => ['autocomplete' => 'off', 'class' => 'flex-column']]); ?>
        <?= $form->field($mesform, 'namemes')->label('Ваше имя')->textInput() ?>
        <?= $form->field($mesform, 'mailmes')->label('Ваша почта')->textInput() ?>
        <?= $form->field($mesform, 'textmes')->label('Сообщение')->textarea() ?>
        <?= Html::submitButton('Отправить сообщение', ['class' => 'btn--site btn--text-contact', 'name' => 'add-button']) ?>
        <?php ActiveForm::end(); ?>
    </div>


</div>