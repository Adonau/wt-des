<?php

/* @var $this yii\web\View */

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/blog';	
$this->title = 'Описание квестов л2 в картинках, полезные квесты л2';
$this->registerMetaTag(['name' => 'description', 'content' => 'в нашем блоге вы найдёте квесты л2 с пошаговым описанием в картинках.']);
$this->registerMetaTag(['name' => 'keywords', 'content' => 'Квесты в картинках л2, описание квестов л2, квесты на рб л2']);
Yii::$app->view->params['title'] = 'Квесты л2 с полным описанием в картинках';
Yii::$app->view->params['undertitle'] = 'полезные заметки по Lineage 2';
?>
<div class="flex-column page page--blog darck--border">

    <div class="headline blog--headline">Важные квесты Lineage 2</div>
    <p>Важной составляющей Lineage 2 являются квесты и походы на рб. В данном разделе мы посторались изложить материал не в сухом остатке, а с наиболее полным описанием, естественно подкрепив всё картинками. База квестов будет постоянно пополнятся, не только квестами на проход к эпикам, но и полезными в плане материального обогащения =).</p>
    <span>Раздел находится  в стадии активного наполнения.<br>Последнее редактирование 18.06.2019</span>
    <div class="flex-row page blog--list-wrap">
        <ul class="flex-column blog--list">
            
        </ul>
        <ul class="flex-column blog--list">
            <li class="flex-row blog--list-item">
                <a href="<?= Yii::$app->urlManager->createUrl(['blog/questantharas']) ?>" class="flex-row blog--item-link">
                    <span class="blog--link-span"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></span>
                    Квест на проход к Антарасу
                </a>
            </li>
            <li class="flex-row blog--list-item">
                <a href="<?= Yii::$app->urlManager->createUrl(['blog/questvalakas']) ?>" class="flex-row blog--item-link">
                    <span class="blog--link-span"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></span>
                    Квест на проход к Валакасу
                </a>
            </li>
        </ul>
    </div>
</div>