<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\AddForm */

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/add';
$this->title = 'Добавить сервер Lineage 2 на L2wt.ru';
$this->registerMetaTag(['name' => 'description', 'content' => 'На этой странице вы можете оставить заявку на размещение вашей рекламы lineage 2.']);
Yii::$app->view->params['title'] = 'Добавить ваш сервер на L2wt.ru';
Yii::$app->view->params['undertitle'] = 'Регистрация сервера ла2';
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use frontend\assets\MyAsset;
use yii\widgets\Pjax;

MyAsset::register($this);
?>
<div class="flex-column page page--add darck--border">
	<div class="flex-row headline form--headline">Регистрация сервера</div>
	<div class="flex-column form-wrap darck--border">
		<ul class="flex-column add--list">
			<li>Администрация может отказать в размещениее без объяснения причин.</li>
			<li>Не допускается плагиат в названии серверов или схожие url (с извезтными проектами, во избежании введения в заблуждение).</li>
			<li>Все сервера проходят модерацию.</li>
			<li>Для связи используйте контакты указанные на соответствующей странице.</li>
			<li>После успешной регистрации вы переместитесь на страницу рекламой, где вы можете ознакомиться с ценами и акциями.</li>
		</ul>
		<?php $form = ActiveForm::begin(['id' => 'form-add-server', 'options' => ['autocomplete' => 'off', 'class' => 'flex-column form--add-server']]); ?>
		<div class="flex-column wrap--main-form">
			<div class="main--headline">Основная информация</div>
			<?= $form->field($addform, 'name')->label('Название сервера')->textInput(['minlength' => 2, 'maxlength' => 26]) ?>
			<?= $form->field($addform, 'url')->label('Url адрес сервера')->textInput() ?>
			<?= $form->field($addform, 'chronicle')->label('Хроники сервера')->dropdownList([
				'Interlude' => 'Interlude',
				'Epilogue' => 'Epilogue',
				'C4' => 'C4',
				'High Five' => 'High Five',
				'GoD' => 'GoD',
				'Lindvior' => 'Lindvior',
				'Gracia Final' => 'Gracia Final',
				'Freya' => 'Freya',
				'Helios' => 'Helios',
				'Classic' => 'Classic',
				'Ertheia' => 'Ertheia',
				'Gr.Crusade' => 'Gr.Crusade',
			]) ?>
			<?= $form->field($addform, 'rate')->label('Рейты сервера')->Input('number') ?>
			<?= $form->field($addform, 'date', ['inputOptions' => ['id' => 'datepicker', 'class' => 'form-control form--date'],])->label('Дата открытия') ?>
		</div>
		<div class="flex-column wrap--dop-form">
			<div class="dop--headline">Дополнительная информация</div>
			<p>В этом разделе вы можете указать какого типа ваш сервер РвР, ГвЕ, Мультипрофа. Имеющиеся акции и бонусы, дополнения. Если проводится обт на вашем сервере, вы так-же можете это указать нажав на соотвествующий чекбокс. Все поля не обязательны и их можно проигнорировать как и сами чекбоксы.</p>
			<div class="flex-row dop--inner-form">
				<div class="flex-column dop--wrap--textarea">
					<?= $form->field($addform, 'textobt')->label('Дополнительная информация по открытому бета тесту, в произвольной форме.')->textarea() ?>
					<?= $form->field($addform, 'textbonus')->label('Дополнителная информация по бонусам и акциям, в произвольной форме.')->textarea() ?>
					<?= $form->field($addform, 'textdop')->label('Дополнителная информация по дополнениям на вашем сервер, в произвольной форме.')->textarea() ?>
				</div>
				<div class="flex-row dop--wrap--check">
					<div class="flex-column dop--list">
						<?= $form->field($addform, 'obt')->label('ОБТ')->checkbox(['value' => 'да']) ?>
						<?= $form->field($addform, 'bonus')->label('Акции и бонусы')->checkbox(['value' => 'да']) ?>
						<?= $form->field($addform, 'dop')->label('Дополнения')->checkbox(['value' => 'да']) ?>
					</div>
					<div class="flex-column dop--list">
						<?= $form->field($addform, 'rvr')->label('РвР')->checkbox(['value' => 'да']) ?>
						<?= $form->field($addform, 'gve')->label('ГвЕ')->checkbox(['value' => 'да']) ?>
						<?= $form->field($addform, 'mult')->label('Мультипрофа')->checkbox(['value' => 'да']) ?>
					</div>
				</div>

			</div>
		</div>
		<?= Html::submitButton('Отправить заявку', ['class' => 'btn--site btn--submit', 'name' => 'add-button']) ?>
		<?php ActiveForm::end(); ?>
	</div>
</div>

<?php
Yii::$app->view->params['title-prefotter'] = '<h2 class="text--la-headline">Регистрация вашего проекта на нашей платформе</h2>';
Yii::$app->view->params['text-prefotter'] = '<p>На данной странице вы можете зарегестрировать ваш проект. Форма регистрации более чем подробная, мы постоянно модернезируем её и улушчаем качество получаемой нами информации о ваших проектах. На форме отсутсвует капча любого рода (для вашего удобства).В разделе "основная информация" находятся обязательные для заполнения поля формы, а в разделе "дополнительная информация" находятся не обязательные поля для заполнение, они служат для более подробного описания вашего сервера и проводимых на нём ивентов, ведётся ли ОБТ, присутсвуют ли дополнения на вашем сервере, заполняется в произвольной форме.</p>';
?>