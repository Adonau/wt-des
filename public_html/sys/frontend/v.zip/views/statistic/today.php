<?php

/* @var $this yii\web\View */
use yii\i18n\Formatter;
use yii\helpers\ArrayHelper;

Yii::$app->view->params['canonical'] = 'https://l2wt.ru/statistic/today';
$this->title = 'Сервера Lineage 2 открытие сегодня';
$this->registerMetaTag(['name' => 'description', 'content' => '"L2wt.ru" Анонсы серверов Lineage 2 всех рейтов и хроник. Открываются сегодня.']);
Yii::$app->view->params['title'] = 'Сервера Lineage 2 открытие сегодня |';
Yii::$app->view->params['undertitle'] = 'пвп и лоу рейт сервера / <b>открытие сегодня</b>';
?>
<div class="flex-row page page--server">

	<div class="flex-column page--server-content server--content-left">
		<div class="headline server--headline">Сервера ожидающие открытия</div>
		<div class="flex-column server--section">
			<div class="flex-column server--container">
				<?php
				$showed = false;
				$today = 'Сегодня';
				?>
				<?php foreach ($list_earlier as $list) : ?>
				<?php
				if ($list->icon_dp == '<i class="dp--icon">MuL</i>') {
					$list->text_dop = $list->getMultText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">GvE</i>') {
					$list->text_dop = $list->text_dop = $list->getGveText($list->text_dop);
				} else if ($list->icon_dp == '<i class="dp--icon">RvR</i>') {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getRvrText($list->text_dop);
				}else {
					$list->text_dop = $list->text_dop = $list->text_dop = $list->getDpText($list->text_dop);	
				}
				?>
					<?php if ($list->date == date('Y-m-d')) : ?>
						<?php if (!$showed) {
							echo '<div class="flex-row server--container-headline headline--low">Сегодня : ' . Yii::$app->formatter->asDate('now', 'full') . '</div>';
							$showed = true;
						} ?>
						<div class="flex-row server--link <?= $list->status ?> <?= $list->getStatus($list->date_end) ?>">
									<?= $list->getStar($list->icon_star) ?>
									<div class="basis--link-item server--item-name">
										<a href="<?= $list->url ?>" target="_blank" rel="nofollow">
											<?= $list->name ?></a>
										<div class="flex-row icon--wrap">
											<div class="basis--link-item server--item-obt">
												<?= $list->icon_obt ?>
												<?= $list->getObtText($list->text_obt) ?>
											</div>
											<div class="basis--link-item server--item-start">
												<?= $list->icon_bonus ?>
												<?= $list->getBonusText($list->text_bonus) ?>
											</div>
										</div>
									</div>
									<?= $list->getMoneyHelp($list->icon_money) ?>
									<?= $list->getRate($list->rate) ?>
									<div class="basis--link-item server--item-chronicle">
										<?= $list->chronicle ?>
										<div class="basis--link-item server--item-dp">
											<?= $list->icon_dp ?>
											<?= $list->text_dop ?>
										</div>
									</div>
									<div class="basis--link-item server--item-date">
										<?= Yii::$app->formatter->asDate($list->date) ?>
									</div>
								</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="flex-column page--server-content server--content-right">
		<div class="headline server--headline">Сервера которые открылись</div>
	</div>

</div>
<?php
Yii::$app->view->params['title-prefotter'] = '<span class="text--la-headline">Ежедневное открытие серверов л2</span>';
Yii::$app->view->params['text-prefotter'] = '<p>Приватные сервера Lineage 2 открываются почти каждый день, с разным качеством сборок и онлайном на старте. Для вашего удобства мы сделали раздел с открытием по дням недели, на данной странице вы можете ознакомится с серверами которые откроются сегодня (не важно когда это сегодня для вас), в меню указано количество открывающихся серверов. Мы надеемся среди этого обилия серверов л2, сегодня вы найдёте для себя тот единственный который вы не захотите покинуть долгое время.</p>' . 
'<div class="flex-row list--dot">
<span></span>
<span></span>
<span></span>
</div>';

Yii::$app->view->params['title-main'] = '<h2 class="text--la-headline">Кратко о сайте L2wt.ru</h2>';
Yii::$app->view->params['text-main'] = '
<p>Платформа L2wt.ru (Lineage 2 web tool | веб инструмент) специализируется на анонсировании частных проектов Lineage 2 данные проекты созданы исключительно для ознакомления игроками с миром Lineage 2 и со всеми его прелестями. Мы стараемся отобрать только надежные проекты (насколько это возможно). Проекты, зарегистрированные у нас, прошли модерацию и мы ознакомились с их концепцией. В ваших же силах воспользоваться нашим сайтом как инструментом, для выбора наилучшего сервера из ряда представленных. Мы стараемся придерживаться минималистического варианта как в дизайне сайта, так и в информации, которая поступает конечному пользователю, без потери исчерпывающих данных.</p>
<div class="flex-row list--dot">
	<span></span>
	<span></span>
	<span></span>
</div>
<ul class="flex-column text--list">
	<li>Структура нашего сайта</li>
	<li>В верхней части сайта расположена навигация по популярным разделам, хроникам и дням недели.</li>
	<li>Слева навигация по всем остальным разделам.</li>
	<li>В левой колонке перечислены сервера, ожидающие открытия, В правой - открывщиеся.</li>
	<li><i class="fa fa-star" aria-hidden="true"></i> - Проект, обладающий данной иконкой, является фаворитом нашего портала.</li>
	<li><i class="fa fa-star-half-o" aria-hidden="true"></i> - Данный вариант показывает, что проект имеет ТОП статус и распологается в верхних строчках списка серверов.</li>
	<li><i class="fa fa-star-o" aria-hidden="true"></i> - Обладатели данной ВИП иконки хотят выделиться по отношению к бесплатно зарегестрированным серверам.</li>
</ul>
';
?>