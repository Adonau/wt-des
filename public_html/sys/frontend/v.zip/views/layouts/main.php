<?php
/* @var $this \yii\web\View */
/* @var $content string */
use frontend\controllers\SiteController;
use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use common\widgets\Alert;
use frontend\widgets\HeaderWidget;
use frontend\widgets\AsideWidget;
use frontend\widgets\StaticWidget;
use frontend\widgets\BigbannerWidget;
use frontend\widgets\TextWidget;
use frontend\widgets\FooterWidget;
use frontend\assets\AppAsset;
use PHPUnit\Framework\Constraint\IsEmpty;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
	<meta charset="<?= Yii::$app->charset ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="yandex-verification" content="82d0ae9b167df750" />
	<meta property="og:type" content="article">
	<meta property="og:url" content="https://l2wt.ru/">
	<meta property="og:image" content="/image/bg_banner/bg-war.jpg">
	<meta property="og:title" content="L2wt.ru - Анонсы серверов Lineage 2">
	<meta property="og:description" content="Анонсы серверов Lineage 2 всех рейтов и хроник. У нас вы найдете только новые сервера л2 которые прошли модерацию и ожидают своих игроков.">
	<meta name="theme-color" content="#060606">
	<?= Html::csrfMetaTags() ?>
	<title><?= Html::encode($this->title) ?></title>
	<link rel="canonical" href="<?= Yii::$app->view->params['canonical'] ?? ''; ?>" />
	<link rel="shortcut icon" href="/favicon.ico" type="image/ico">
	<?php $this->head() ?>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-140782951-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());
		gtag('config', 'UA-140782951-1');
	</script>
</head>
<body>
	<?php $this->beginBody() ?>
	<?php echo HeaderWidget::widget() ?>
	<?php echo StaticWidget::widget() ?>
	<div class=" flex-row wrapper gray--border">
		<div class="flex-column wrap--page">
			<div class="flex-row article">
				<div class="flex-column wrap--content">
					<?php echo BigbannerWidget::widget() ?>
					<?= $content ?>
				</div>
			</div>
			<?php echo TextWidget::widget() ?>
		</div>
		<?php echo AsideWidget::widget() ?>
		<div id="go-top" class="iconfont icon-cc-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</div>
	</div>
	<?php echo FooterWidget::widget() ?>
	<?php $this->endBody() ?>
	<!-- Yandex.Metrika counter -->
	<script>
		(function(m, e, t, r, i, k, a) {
			m[i] = m[i] || function() {
				(m[i].a = m[i].a || []).push(arguments)
			};
			m[i].l = 1 * new Date();
			k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k, a)
		})
		(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
		ym(53818963, "init", {
			clickmap: true,
			trackLinks: true,
			accurateTrackBounce: true,
			webvisor: true
		});
	</script>
	<noscript>
		<div><img src="https://mc.yandex.ru/watch/53818963" style="position:absolute; left:-9999px;" alt="" /></div>
	</noscript>
	<!-- /Yandex.Metrika counter -->
</body>
</html>
<?php $this->endPage() ?>